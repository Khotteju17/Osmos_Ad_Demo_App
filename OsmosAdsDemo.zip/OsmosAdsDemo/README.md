# Osmos Ads iOS Demo

Native iOS demo application for fetching, rendering, and tracking display banner ads with the Osmos Ads SDK.

## Assignment coverage

This project implements the requested Osmos Ads flow:

- Native iOS / SwiftUI application
- Osmos SDK initialization
- Display-ad fetching using an Ad Unit (AU)
- `cliUbid = Any`
- `pageType = demo_page`
- `adUnit = banner_ads`
- Dynamic rendering of returned banner images
- Multiple ads in a scrollable view
- 50% visibility-based impression detection
- One impression per ad
- Click tracking through the Osmos SDK
- Opening `elements.destination_url` after a click
- Loading and fallback states
- Retry support
- Duplicate-request protection
- Lifecycle-aware loading
- Structured logging with `OSLog`
- In-app event log for demonstrating ad load, impression, click, and fallback events

## Configuration

The assignment configuration is kept in `OsmosConfiguration.swift`:

```text
clientId       = 10088010
productAdsHost = demo.o-s.io
displayAdsHost = demo-ba.o-s.io
cliUbid        = Any
pageType       = demo_page
adUnit         = banner_ads
```

## Project structure

```text
OsmosAdsDemo 2/
├── OsmosAdsDemoApp.swift
├── AppLogger.swift
├── README.md
├── Ads/
│   ├── Models/
│   │   └── AdModel.swift
│   ├── Services/
│   │   ├── AdService.swift
│   │   ├── OsmosConfiguration.swift
│   │   └── OsmosSDKAdapter.swift
│   ├── Tracking/
│   │   └── ImpressionTracker.swift
│   └── Visibility/
│       └── VisibilityTracker.swift
└── Features/
    └── BannerAds/
        ├── BannerAdCard.swift
        ├── BannerAdsView.swift
        └── BannerAdsViewModel.swift
```

### Architecture

`BannerAdsView` is the UI layer. `BannerAdsViewModel` owns UI state and coordinates loading/tracking. `AdService` provides a small application-level abstraction around the SDK. `OsmosSDKAdapter` contains Osmos-specific SDK calls and response parsing.

This keeps SDK details out of the SwiftUI views and makes the visibility and tracking helpers reusable.

## How ad fetching works

When the screen appears:

1. The Osmos SDK is initialized.
2. `AdService` asks `OsmosSDKAdapter` to fetch display ads.
3. The SDK is called with the configured AU values.
4. The response is parsed from `ads.banner_ads`.
5. The app extracts the banner image URL, destination URL, tracking URLs, `uclid`, width, and height.
6. The returned ads are rendered in a vertical `ScrollView`.

The **Load Ad** button can also trigger another fetch. Requests are guarded by `isLoading` so duplicate fetches are ignored.

## Impression tracking: 50% visibility

Each `BannerAdCard` uses the reusable `VisibilityTracker` with a threshold of `0.5`.

The helper calculates the intersection between the ad's global frame and the key window bounds:

```text
visible area / total ad area >= 0.5
```

When at least 50% of the ad is visible, the impression callback is triggered. `BannerAdCard` and `ImpressionTracker` both protect against duplicate impression callbacks for the same ad.

The Osmos impression event is then registered using the ad's `uclid` and its position in the list.

## Click tracking

Tapping a banner:

1. Registers the Osmos click event using the ad's `uclid`.
2. Opens `elements.destination_url` when one is available.
3. Adds the event to the in-app Event Log.

## Error handling and fallback

The app handles:

- SDK initialization failure
- Empty/no-ad responses
- Fetch failures
- Missing `uclid` for tracking
- Missing destination URLs
- Banner image loading failures
- Duplicate requests

The normal fallback UI displays **Ad not available** and provides a **Retry** button.

For assignment/demo verification, the UI also includes **Simulate No Ads**. This intentionally enters the same fallback state without requiring a real network failure, making the no-ad/error flow easy to demonstrate during review.

## Event logging

Events are written using `OSLog` through `AppLogger` and are also shown in the on-screen **Event Log**.

The Event Log can demonstrate:

- `Ad Loaded`
- `Ad Failed`
- `Impression Fired`
- `Click Fired`
- `Opening landing URL`
- Retry/fallback actions

## How to run

1. Open `OsmosAdsDemo.xcodeproj` in Xcode.
2. Resolve the Swift Package dependency if Xcode prompts for it.
3. Select an iOS Simulator or connected iOS device.
4. Build and run the application.
5. The app automatically attempts an initial ad load.
6. Use **Load Ad** to manually fetch ads again.

## Demo / verification checklist

### 1. Ad loading

- Launch the app.
- Confirm the loading indicator appears.
- Confirm the status changes to something like `3 ad(s) loaded` when ads are returned.
- Confirm `Ad Loaded` appears in the Event Log.

### 2. Banner rendering

- Confirm returned banner images appear in the scrollable list.
- Scroll through multiple ads.

### 3. Impression event

- Position an ad so at least 50% of it is visible.
- Keep it visible long enough for the visibility callback to run.
- Confirm `Impression Fired` appears in the Event Log.
- Scroll away and back to confirm the same ad is not counted repeatedly.

### 4. Click event

- Tap a banner.
- Confirm `Click Fired` appears in the Event Log.
- Confirm `Opening landing URL` appears when the ad contains a destination URL.
- Confirm the destination opens.

### 5. No-ad / error scenario

- Tap **Simulate No Ads**.
- Confirm the UI displays **Ad not available**.
- Confirm the demo fallback event appears in the Event Log.
- Tap **Retry** or **Load Ad** to return to the normal fetch flow.

## Submission demo recording

A short recording should show:

1. App launch and ad loading
2. Multiple banner ads rendered
3. An ad reaching the 50% visibility threshold and `Impression Fired`
4. A banner tap and `Click Fired`
5. The landing URL opening
6. **Simulate No Ads** showing the fallback UI
7. Retry / Load Ad returning to the fetch flow

## Assumptions

- The Osmos SDK remains responsible for the actual impression and click event registration APIs.
- The app uses the `uclid` returned with each banner for SDK event registration.
- A banner without a valid image URL is not rendered as an ad model.
- The assignment's requested fallback behavior is demonstrated through the `Simulate No Ads` control so the error state can be reproduced reliably during evaluation.

## Challenges / implementation notes

The response is parsed from the SDK response's `response.data` JSON string. Banner width and height are parsed flexibly because the values may arrive as either numeric values or numeric strings. The UI uses those dimensions when available to preserve the banner's supplied aspect ratio.
