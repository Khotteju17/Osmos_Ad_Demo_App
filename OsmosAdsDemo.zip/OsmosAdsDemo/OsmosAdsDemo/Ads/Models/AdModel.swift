//
//  AdModel.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation

struct AdModel: Identifiable, Equatable {
    let id: String
    let imageURL: URL
    let destinationURL: URL?
    let impressionTrackingURL: URL?
    let clickTrackingURL: URL?
    let uclid: String?
    let width: CGFloat?
    let height: CGFloat?
}
