//
//  ImpressionTracker.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation
import Combine

@MainActor
final class ImpressionTracker: ObservableObject {
    private var trackedAdIDs: Set<String> = []

    func shouldTrack(ad: AdModel) -> Bool {
        guard !trackedAdIDs.contains(ad.id) else {
            return false
        }

        trackedAdIDs.insert(ad.id)
        return true
    }

    func reset() {
        trackedAdIDs.removeAll()
    }
}
