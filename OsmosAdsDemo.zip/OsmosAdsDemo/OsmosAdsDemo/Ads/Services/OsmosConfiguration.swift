//
//  OsmosConfiguration.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation

enum OsmosConfiguration {
    
    static let clientId = 10088010
    
    static let productAdsHost = "demo.o-s.io"
    
    static let displayAdsHost = "demo-ba.o-s.io"
    
    static let cliUbid = "Any"
    
    static let pageType = "demo_page"
    
    static let adUnit = "banner_ads"
}

