//
//  AdService.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation

protocol AdServiceProtocol {
    func initialize() async throws
    func fetchAds() async throws -> [AdModel]
    func trackImpression(for ad: AdModel, position: Int) async
    func trackClick(for ad: AdModel) async
}

final class AdService: AdServiceProtocol {
    private let sdk: OsmosSDKAdapterProtocol

    init(sdk: OsmosSDKAdapterProtocol = OsmosSDKAdapter()) {
        self.sdk = sdk
    }

    func initialize() async throws {
        try await sdk.initialize()
    }

    func fetchAds() async throws -> [AdModel] {
        let ads = try await sdk.fetchDisplayAds(
            cliUbid: OsmosConfiguration.cliUbid,
            pageType: OsmosConfiguration.pageType,
            adUnit: OsmosConfiguration.adUnit
        )

        guard !ads.isEmpty else {
            throw AdServiceError.noAds
        }

        return ads
    }

    func trackImpression(for ad: AdModel, position: Int) async {
        do {
            try await sdk.registerImpression(for: ad, position: position)
            AppLogger.info("Impression Fired: \(ad.id), position: \(position)")
        } catch {
            AppLogger.error("Impression failed for \(ad.id): \(error.localizedDescription)")
        }
    }

    func trackClick(for ad: AdModel) async {
        do {
            try await sdk.registerClick(for: ad)
            AppLogger.info("Click Fired: \(ad.id)")
        } catch {
            AppLogger.error("Click tracking failed for \(ad.id): \(error.localizedDescription)")
        }
    }
}

enum AdServiceError: LocalizedError {
    case noAds

    var errorDescription: String? {
        switch self {
        case .noAds:
            return "No ads available."
        }
    }
}
