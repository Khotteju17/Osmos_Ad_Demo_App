//
//  OsmosSDKAdapter.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation
import osmos

protocol OsmosSDKAdapterProtocol {

    func initialize() async throws

    func fetchDisplayAds(
        cliUbid: String,
        pageType: String,
        adUnit: String
    ) async throws -> [AdModel]

    func registerImpression(
        for ad: AdModel,
        position: Int
    ) async throws

    func registerClick(
        for ad: AdModel
    ) async throws
}

final class OsmosSDKAdapter: OsmosSDKAdapterProtocol {

    private var isInitialized = false

    // MARK: - Initialization

    func initialize() async throws {

        guard !isInitialized else {
            return
        }

        try OSMOS.Builder()
            .clientId(String(OsmosConfiguration.clientId))
            .debug(true)
            .displayAdsHost(OsmosConfiguration.displayAdsHost)
            .productAdsHost(OsmosConfiguration.productAdsHost)
            .buildGlobalInstance()

        isInitialized = true

        AppLogger.info("OSMOS SDK initialized")
    }

    // MARK: - Fetch Ads

    func fetchDisplayAds(
        cliUbid: String,
        pageType: String,
        adUnit: String
    ) async throws -> [AdModel] {

        let osmosManager = try OSMOS.shared()

        guard let adFetcher = osmosManager.adFetcher() else {
            throw OsmosSDKError.adFetcherUnavailable
        }

        AppLogger.info(
            "Fetching ads: cliUbid=\(cliUbid), pageType=\(pageType), adUnit=\(adUnit)"
        )

        let response = await adFetcher.fetchDisplayAdsWithAu(
            cliUbid: cliUbid,
            pageType: pageType,
            productCount: 5,
            adUnits: [adUnit],
            targetingParams: nil,
            onError: { error in
                AppLogger.error(
                    "OSMOS fetch error: \(error.localizedDescription)"
                )
            }
        )

        guard let response = response else {
            throw OsmosSDKError.noResponse
        }

        AppLogger.debug(
            "OSMOS response: \(String(describing: response))"
        )

        return parseAds(from: response)
    }

    // MARK: - Impression

    func registerImpression(
        for ad: AdModel,
        position: Int
    ) async throws {

        let osmosManager = try OSMOS.shared()

        guard let registerEvent = osmosManager.registerEvent() else {
            throw OsmosSDKError.eventTrackerUnavailable
        }

        guard let uclid = ad.uclid else {
            throw OsmosSDKError.missingUclid
        }

        _ = await registerEvent.registerAdImpressionEvent(
            cliUbid: OsmosConfiguration.cliUbid,
            uclid: uclid,
            position: position,
            onError: { error in
                AppLogger.error(
                    "Impression event error: \(error.localizedDescription)"
                )
            }
        )

        AppLogger.info(
            "Impression Fired: \(ad.id), position: \(position)"
        )
    }

    // MARK: - Click

    func registerClick(
        for ad: AdModel
    ) async throws {

        let osmosManager = try OSMOS.shared()

        guard let registerEvent = osmosManager.registerEvent() else {
            throw OsmosSDKError.eventTrackerUnavailable
        }

        guard let uclid = ad.uclid else {
            throw OsmosSDKError.missingUclid
        }

        _ = await registerEvent.registerAdClickEvent(
            cliUbid: OsmosConfiguration.cliUbid,
            uclid: uclid,
            trackingParams: nil,
            onError: { error in
                AppLogger.error(
                    "Click event error: \(error.localizedDescription)"
                )
            }
        )

        AppLogger.info(
            "Click Fired: \(ad.id)"
        )
    }

    // MARK: - Response Parsing

    
    private func parseAds<T>(from response: T) -> [AdModel] {

        guard let responseDictionary = response as? [String: Any] else {
            AppLogger.error("OSMOS response is not [String: Any]")
            return []
        }

        guard let innerResponse = responseDictionary["response"] as? [String: Any] else {
            AppLogger.error("OSMOS response does not contain 'response'")
            return []
        }

        guard let dataString = innerResponse["data"] as? String else {
            AppLogger.error("OSMOS response does not contain 'data' string")
            return []
        }

        guard let jsonData = dataString.data(using: .utf8) else {
            AppLogger.error("Unable to convert OSMOS data to Data")
            return []
        }

        do {

            let decoded = try JSONDecoder().decode(
                OsmosResponse.self,
                from: jsonData
            )

            let ads = decoded.ads.banner_ads.compactMap { bannerAd -> AdModel? in

                // Image is mandatory
                guard
                    let imageString = bannerAd.elements.value,
                    let imageURL = URL(string: imageString)
                else {
                    AppLogger.error("Ad \(bannerAd.rank ?? 0): missing image URL")
                    return nil
                }
                AppLogger.info(
                    "Ad \(bannerAd.rank ?? 0) image URL: \(imageURL.absoluteString)"
                )

                let destinationURL: URL?

                if let destinationString = bannerAd.elements.destination_url {
                    destinationURL = URL(string: destinationString)
                } else {
                    destinationURL = nil
                }

                let impressionURL = bannerAd.impression_tracking_url.flatMap {
                    URL(string: $0)
                }

                let clickURL = bannerAd.click_tracking_url.flatMap {
                    URL(string: $0)
                }

                return AdModel(
                    id: bannerAd.uclid ?? UUID().uuidString,
                    imageURL: imageURL,
                    destinationURL: destinationURL,
                    impressionTrackingURL: impressionURL,
                    clickTrackingURL: clickURL,
                    uclid: bannerAd.uclid,
                    width: bannerAd.elements.width?.value,
                    height: bannerAd.elements.height?.value
                )
            }

            AppLogger.info(
                "Parsed \(ads.count) OSMOS banner ad(s)"
            )

            return ads

        } catch {

            AppLogger.error(
                "OSMOS JSON parsing failed: \(error)"
            )

            return []
        }
    }
    // MARK: - Response Models

    private struct OsmosResponse: Decodable {
        let ads: AdsContainer
    }

    private struct AdsContainer: Decodable {
        let banner_ads: [OsmosBannerAd]
    }

    private struct OsmosBannerAd: Decodable {

        let elements: OsmosElements

        let click_tracking_url: String?
        let impression_tracking_url: String?

        let uclid: String?
        let rank: Int?
    }

    private struct OsmosElements: Decodable {

        let type: String?
        let value: String?

        let destination_url: String?

        let width: FlexibleCGFloat?
        let height: FlexibleCGFloat?
    }


    private struct FlexibleCGFloat: Decodable {

        let value: CGFloat

        init(from decoder: Decoder) throws {

            let container = try decoder.singleValueContainer()

            if let number = try? container.decode(Double.self) {
                value = CGFloat(number)
                return
            }

            if let string = try? container.decode(String.self),
               let number = Double(string) {
                value = CGFloat(number)
                return
            }

            throw DecodingError.typeMismatch(
                CGFloat.self,
                DecodingError.Context(
                    codingPath: decoder.codingPath,
                    debugDescription: "Expected number or numeric string"
                )
            )
        }
    }
}

// MARK: - Errors

enum OsmosSDKError: LocalizedError {

    case adFetcherUnavailable
    case eventTrackerUnavailable
    case noResponse
    case missingUclid

    var errorDescription: String? {

        switch self {

        case .adFetcherUnavailable:
            return "OSMOS ad fetcher is unavailable."

        case .eventTrackerUnavailable:
            return "OSMOS event tracker is unavailable."

        case .noResponse:
            return "OSMOS returned no response."

        case .missingUclid:
            return "Ad is missing uclid."
        }
    }
}
