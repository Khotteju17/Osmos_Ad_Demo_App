//
//  VisibilityTracker.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import UIKit
import SwiftUI



struct VisibilityTracker: ViewModifier {
    
    let threshold: CGFloat
    let onVisibilityChanged: (Bool) -> Void
    
    func body(content: Content) -> some View {
        
        content
            .background(
                GeometryReader { geometry in
                    
                    Color.clear
                        .onAppear {
                            checkVisibility(
                                frame: geometry.frame(
                                    in: .global
                                )
                            )
                        }
                        .onChange(
                            of: geometry.frame(in: .global)
                        ) { newFrame in
                            
                            checkVisibility(frame: newFrame)
                        }
                }
            )
    }
    
    private func checkVisibility(frame: CGRect) {
        
        guard let window = UIApplication.shared
            .connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap({ $0.windows })
            .first(where: { $0.isKeyWindow })
        else {
            return
        }
        
        let screenBounds = window.bounds
        
        let visibleRect = frame.intersection(screenBounds)
        
        guard !visibleRect.isNull,
              frame.width > 0,
              frame.height > 0
        else {
            onVisibilityChanged(false)
            return
        }
        
        let visibleArea = visibleRect.width * visibleRect.height
        
        let totalArea = frame.width * frame.height
        
        let visiblePercentage = visibleArea / totalArea
        
        onVisibilityChanged(
            visiblePercentage >= threshold
        )
    }
}

extension View {
    
    func trackVisibility(
        threshold: CGFloat = 0.5,
        onVisibilityChanged: @escaping (Bool) -> Void
    ) -> some View {
        
        modifier(
            VisibilityTracker(
                threshold: threshold,
                onVisibilityChanged: onVisibilityChanged
            )
        )
    }
}
