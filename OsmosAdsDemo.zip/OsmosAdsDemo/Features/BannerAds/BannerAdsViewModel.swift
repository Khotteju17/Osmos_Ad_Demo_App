//
//  BannerAdsViewModel.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation
import SwiftUI
import Combine

@MainActor
final class BannerAdsViewModel: ObservableObject {
    @Published private(set) var ads: [AdModel] = []
    @Published private(set) var isLoading = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var statusMessage = "Ready"
    @Published private(set) var eventLog: [String] = []

    private let adService: AdServiceProtocol
    private var hasInitializedSDK = false

    init(adService: AdServiceProtocol = AdService()) {
        self.adService = adService
    }

    // MARK: - SDK Initialization

    func initialize() async {
        guard !hasInitializedSDK else {
            return
        }

        do {
            try await adService.initialize()
            hasInitializedSDK = true
            AppLogger.info("Osmos SDK initialized successfully")
        } catch {
            errorMessage = "Ad not available"
            statusMessage = "SDK initialization failed"
            AppLogger.error("SDK initialization failed: \(error.localizedDescription)")
            recordEvent("Ad Failed: SDK initialization")
        }
    }

    // MARK: - Load Ads

    func loadAds() async {
        guard !isLoading else {
            AppLogger.debug("Ignoring duplicate ad request")
            return
        }

        isLoading = true
        errorMessage = nil
        statusMessage = "Loading..."
        defer { isLoading = false }

        if !hasInitializedSDK {
            await initialize()
            guard hasInitializedSDK else { return }
        }

        do {
            let fetchedAds = try await adService.fetchAds()
            guard !fetchedAds.isEmpty else {
                throw AdServiceError.noAds
            }

            ads = fetchedAds
            errorMessage = nil
            statusMessage = "\(fetchedAds.count) ad(s) loaded"
            recordEvent("Ad Loaded: \(fetchedAds.count) ad(s)")
            AppLogger.info("Ad Loaded: \(fetchedAds.count) ad(s)")
        } catch {
            ads = []
            errorMessage = "Ad not available"
            statusMessage = "Ad Failed"
            recordEvent("Ad Failed: \(error.localizedDescription)")
            AppLogger.error("Ad Failed: \(error.localizedDescription)")
        }
    }

    // MARK: - Demo Error State

    func simulateNoAds() {
        ads = []
        isLoading = false
        errorMessage = "Demo mode: simulated no ads response."
        statusMessage = "Ad Failed (Demo)"
        recordEvent("Demo: simulated no ads / fallback UI")
        AppLogger.info("Demo: simulated no ads / fallback UI")
    }

    // MARK: - Retry

    func retry() async {
        guard !isLoading else { return }

        recordEvent("Retrying ad fetch")
        AppLogger.info("Retrying ad fetch")
        errorMessage = nil
        statusMessage = "Retrying..."
        await loadAds()
    }

    // MARK: - Tracking

    func trackImpression(for ad: AdModel, position: Int) async {
        await adService.trackImpression(for: ad, position: position)
        recordEvent("Impression Fired: ad \(position)")
    }

    func trackClick(for ad: AdModel) async {
        await adService.trackClick(for: ad)
        recordEvent("Click Fired: \(ad.id)")
    }

    // MARK: - UI Logging

    func recordEvent(_ message: String) {
        eventLog.insert(message, at: 0)
        eventLog = Array(eventLog.prefix(8))
    }

    func clearEventLog() {
        eventLog.removeAll()
    }
}
