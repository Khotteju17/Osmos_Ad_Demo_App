//
//  BannerAdCard.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import SwiftUI

struct BannerAdCard: View {
    let ad: AdModel
    let onImpression: () -> Void
    let onClick: () -> Void

    @State private var impressionTriggered = false

    private var suppliedAspectRatio: CGFloat? {
        guard let width = ad.width,
              let height = ad.height,
              width > 0,
              height > 0 else {
            return nil
        }
        return width / height
    }

    var body: some View {
        Button {
            onClick()
        } label: {
            AsyncImage(url: ad.imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(maxWidth: .infinity, minHeight: 180)

                case .success(let image):
                    image
                        .resizable()
                        .aspectRatio(
                            suppliedAspectRatio,
                            contentMode: .fit
                        )
                        .frame(maxWidth: .infinity)

                case .failure:
                    VStack(spacing: 8) {
                        Image(systemName: "photo")
                            .font(.largeTitle)
                        Text("Image failed")
                            .font(.headline)
                        Text("Unable to load the banner image.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, minHeight: 180)

                @unknown default:
                    EmptyView()
                }
            }
        }
        .buttonStyle(.plain)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.secondarySystemBackground))
        )
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .trackVisibility(threshold: 0.5) { isVisible in
            guard isVisible, !impressionTriggered else {
                return
            }

            impressionTriggered = true
            onImpression()
        }
    }
}
