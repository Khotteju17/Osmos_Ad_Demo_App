//
//  BannerAdsView.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import SwiftUI
import UIKit

struct BannerAdsView: View {
    @StateObject private var viewModel = BannerAdsViewModel()
    @StateObject private var impressionTracker = ImpressionTracker()
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    Text("Osmos Ads")
                        .font(.title)
                        .bold()

                    statusView
                    controlsView

                    if viewModel.isLoading {
                        loadingView
                    } else if viewModel.ads.isEmpty {
                        fallbackView
                    } else {
                        adsView
                    }
}
                .padding()
            }
        }
        .task {
            await viewModel.initialize()
            await viewModel.loadAds()
        }
        .onChange(of: scenePhase) { _, newPhase in
            guard newPhase == .active, viewModel.ads.isEmpty else {
                return
            }

            Task {
                await viewModel.loadAds()
            }
        }
    }

    // MARK: - Status

    private var statusView: some View {
        Text(viewModel.statusMessage)
            .font(.caption)
            .foregroundStyle(.secondary)
    }

    // MARK: - Controls

    private var controlsView: some View {
        VStack(spacing: 10) {
            Button {
                Task {
                    impressionTracker.reset()
                    await viewModel.loadAds()
                }
            } label: {
                Label("Load Ad", systemImage: "arrow.down.circle.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading)

            HStack(spacing: 10) {
                Button("Simulate No Ads") {
                    impressionTracker.reset()
                    viewModel.simulateNoAds()
                }
                .buttonStyle(.bordered)
                .disabled(viewModel.isLoading)

                Button("Clear Events") {
                    viewModel.clearEventLog()
                }
                .buttonStyle(.bordered)
            }
        }
    }

    // MARK: - Loading

    private var loadingView: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text("Loading ad...")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 40)
    }

    // MARK: - Fallback

    private var fallbackView: some View {
        VStack(spacing: 12) {
            Image(systemName: "rectangle.slash")
                .font(.largeTitle)
                .foregroundStyle(.secondary)

            Text("Ad not available")
                .font(.headline)

            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            Button("Retry") {
                Task {
                    impressionTracker.reset()
                    await viewModel.retry()
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 40)
    }

    // MARK: - Ads

    private var adsView: some View {
        VStack(spacing: 16) {
            ForEach(Array(viewModel.ads.enumerated()), id: \.element.id) { index, ad in
                BannerAdCard(
                    ad: ad,
                    onImpression: {
                        guard impressionTracker.shouldTrack(ad: ad) else {
                            return
                        }

                        Task {
                            await viewModel.trackImpression(
                                for: ad,
                                position: index + 1
                            )
                        }
                    },
                    onClick: {
                        Task {
                            await viewModel.trackClick(for: ad)

                            if let destinationURL = ad.destinationURL {
                                viewModel.recordEvent("Opening landing URL")
                                await UIApplication.shared.open(destinationURL)
                            } else {
                                viewModel.recordEvent("Click: no destination URL")
                            }
                        }
                    }
                )
            }
        }
    }
}
