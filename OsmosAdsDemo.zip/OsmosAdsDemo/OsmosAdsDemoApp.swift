//
//  OsmosAdsDemoApp.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import SwiftUI

@main
struct OsmosAdsDemoApp: App {
    var body: some Scene {
        WindowGroup {
            BannerAdsView()
        }
    }
}
