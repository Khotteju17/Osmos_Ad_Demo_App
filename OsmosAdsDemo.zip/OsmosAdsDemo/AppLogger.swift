//
//  AppLogger.swift
//  OsmosAdsDemo
//
//  Created by Tejashree Khot on 01/10/26.
//

import Foundation
import OSLog

enum AppLogger {
    
    private static let logger = Logger(
        subsystem: Bundle.main.bundleIdentifier ?? "OsmosAdsDemo",
        category: "Ads"
    )
    
    static func info(_ message: String) {
        logger.info("\(message, privacy: .public)")
    }
    
    static func error(_ message: String) {
        logger.error("\(message, privacy: .public)")
    }
    
    static func debug(_ message: String) {
        logger.debug("\(message, privacy: .public)")
    }
}
